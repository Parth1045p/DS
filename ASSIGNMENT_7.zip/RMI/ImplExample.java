public class ImplExample implements Hello {  
   
   // Implementing the interface method 
   public void addNum(int x, int y) {  
      int result = x + y;
      System.out.println("Addition is : " + result);  
   }  
}